document.getElementById("contactForm").addEventListener("submit", function(event) {
  event.preventDefault(); 
  window.location.href = "../thanks"; 
});

